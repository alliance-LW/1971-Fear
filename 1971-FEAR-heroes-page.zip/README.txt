1971 FEAR HERO PAGE

1. Rename heroes-with-pictures.html to heroes.html (or upload it as heroes.html).
2. Put it in the same GitHub folder as index.html, vs.html and combat.html.
3. The page contains 31 hero cards and loads hero portraits from a public hero image library.
4. If a portrait cannot load, a visible initials tile appears instead of an empty space.
